# TechExam1

You are given a post api that accept string as an input. 
Your task is to optimize the function that counts the number of unique characters in the given string.
Please explain why your solution is much more optimize than the current.
Put your explanations below.

# Note 

If your solution came from ChatGPT you are automatically failed.


# Input:

A string "input" consisting of lowercase and/or uppercase letters and may contain special characters and the string length is n.

# Output:

An integer representing the count of unique characters in the string.

# Example

The given string "pneumonoultramicroscopicsilicovolcanoconiosis" contains 3 unique characters: {'e', 't', 'v'}.

# TestInput

"input" :"Whispers of the Night In the quiet of the moon's embrace, Where shadows dance and secrets trace, The night unfolds its velvet wings, And stars ignite like ancient things. The breeze, a soft and tender kiss, Caresses leaves in whispered bliss, As crickets hum their lullabies, And dreams take flight in moonlit skies. Beneath the silver canopy, The world slows down, and hearts break free, For darkness holds a mystic spell, Where time stands still, and all is well. So close your eyes, my weary friend, And let the night its solace send, For in these hours, we find our grace,And dance with stars in silent space."


# Explanation:
1. As I observed in the interface Service and service, these class applied the async method but did not implement it properly. Because no await operator is applied, the program continues without waiting for the task to complete.
2. By simply applying the await task at the controller and replacing the method to simply return an int.