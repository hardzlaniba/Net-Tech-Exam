﻿namespace TechExam1.Models
{
    public class UniqueCharacterRequest
    {
        public string Input { get; set; } = string.Empty;
    }
}
