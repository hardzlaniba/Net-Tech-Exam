﻿namespace TechExam1.Models
{
    public class UniqueCharacterResponse
    {
        public int UniqueCharacterCount { get; set; }
    }
}
