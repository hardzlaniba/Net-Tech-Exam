# TechExam # 3

You are given an Employee API that can perform this basic functions: Create, Read, Update and Delete record

Your task is to create an unit testing that covers the whole application.

Your test should covered both Positive and Negative test and You may add your own custom validation.

You can choose whatever unit test library you want e.g MSTest, NUnit, and xUnit


# Example Test

Name must not be null or empty.

Name must not contains this special characters "!@#$%^&*()_-=+;:<>?/\|".

Name must not exceed 100 characters.

With this current validation, 

My unit test on Add and Edit should pass when I input a valid name that is not null and doesn't contains invalid inputs.

And it should fail if I input a null, special characters, and 200 character lenght Name.

* Note: This is a only a sample tests that you can do. Remember that you need to create an unit tests that covers the whole application. 


My unit test results using MSTest:
1. Adjust first the code due to dependency injection error. As observed that dependency injection is not properly implemented.
2. GetEmployeeList:
 - ID must be number only.
 - ID must not be null or empty.
 - ID must not be a special character.
 - With this current validation, my unit test to get the employee information should pass if I input a number and doesn't contains any invalid inputs. 
3. CreateEmployee:
 - Name must not be null or empty.
 - Name only accepts letter a, z and s.
 - Name must not exceed to 1 character only.
 - With this current validation, creation of employee should pass if I input only letters a, z and s and must not exceed to 1 character and doesn't contains any invalid inputs.
4. 