using Microsoft.AspNetCore.Mvc;
using Moq;
using TechExam3.Controllers;
using TechExam3.Interface;
using TechExam3.IRepository;
using TechExam3.Model;

namespace TestProject
{
    /// <summary>
    /// using MStest
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// test and get employee based on id number 
        /// </summary>
        [TestMethod]
        public void GetEmployee()
        {
            // Arrange
            // get employee id 1, John Doe
            var id = 1;
            var mockUserService = new Mock<IEmployeeRepository>();
            var mockUserValidation = new Mock<IEmployeeValidator>();
            //mockUserService.Setup(x => x.GetEmployee(It.IsAny<int>())).Returns(new List<EmployeeModel> { });
            var expected = new List<EmployeeModel>(){
                new EmployeeModel {
                    Id = id,
                    Name = "John Doo", 
                    Position = "",
                    Email = "",
                    PhoneNumber = "",
                    Address = "",
                    IsActive = true
                },
                //new EmployeeModel {
                //    Name = "", 
                //    //populate other properties  
                //}
            };

            //using moq to mimic dependencies
            mockUserService.Setup(x => x.GetEmployee(It.IsAny<int>())).Returns(expected);
            //mockUserService.Setup(x => x.GetEmployee(id)).Returns(expected);

            var controller = new EmployeeController(mockUserService.Object, mockUserValidation.Object);

            // Act
            var actual = controller.GetEmployeeList(id);
            var result = actual as ObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.IsNotNull(result.Value);
            Assert.AreSame(expected, actual);
        }
    }
}