﻿namespace TechExam3.Model
{
    public class AddEmployeeRequest
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
    }
}
