﻿namespace TechExam3.Model
{
    public class ValidatorResponse
    {
        public bool HasError { get; set; }
        public string ErrorMessage { get; set; }
    }
}
