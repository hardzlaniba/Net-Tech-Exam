﻿namespace TechExam2.Model
{
    public class CalculateRequest
    {
        public int FirstNumber { get; set; }
        public int SecondNumber { get; set; }
    }
}
