﻿namespace TechExam2.Model
{
    public class CalculateResponse
    {
        public int Answer { get; set; }
    }
}
