# TechExam2

You are given an api that accept 2 integer as an input and returns an integer which is the rounded value of the sum of the 2 Interger input.
you will round up the sum based on this condition:
- If the difference between the sum and the next multiple of 5 is less than 3, round up to the next multiple of 5 else don't round it up.

Your task is to debug the project and make it work.

# Input:

2 int and should be both whole number.

# Output:

An integer representing the sum or the rounded up value.

# Example

The given FirstNumber = 13 and the SecondNumber = 10 the reponse should be 25 since the sum of 2 int is 23 the next multiple of 5 is 25

The given FirstNumber = 30 and the SecondNumber = 27 the reponse should be 57 since the sum of 2 int is 57 and the next multiple of 5 is 60 and 60 - 57 is 3;
